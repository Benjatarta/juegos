const formNombres = document.getElementById("formNombres");
const inputNombre = document.getElementById("inputNombre");
const boton = document.getElementById("boton");
const animacion = document.getElementById("animacion");
const listaColores = document.getElementById("listaColores");
let nombres = [];

let colores = [
  { color: "Azul", valor: "azul", boton: document.getElementById("azul") },
  { color: "Rojo", valor: "rojo", boton: document.getElementById("rojo") },
  { color: "Verde", valor: "verde", boton: document.getElementById("verde") },
  { color: "Amarillo", valor: "amarillo", boton: document.getElementById("amarillo") }
];

let secuenciaSimón = [];
let secuenciaJugador = [];
let enJuego = false;

function mostrarColores() {
  listaColores.innerHTML = '';
  colores.forEach(c => {
    const li = document.createElement("li");
    li.classList.add("list-group-item");
    li.textContent = `${c.color}`;
    listaColores.appendChild(li);
  });
}

function generarSecuencia() {
  const colorAleatorio = colores[Math.floor(Math.random() * colores.length)];
  secuenciaSimón.push(colorAleatorio);
  mostrarSecuencia();
}

function iluminarColor(color) {
  color.boton.classList.add("iluminar");
  setTimeout(() => {
    color.boton.classList.remove("iluminar");
  }, 500); // Duración de la iluminación (500 ms)
}

function mostrarSecuencia() {
  animacion.classList.add("ani");
  secuenciaSimón.forEach((color, index) => {
    setTimeout(() => {
      iluminarColor(color);
    }, 1000 * (index + 1));
  });

  setTimeout(() => {
    enJuego = true;
    secuenciaJugador = [];
  }, 1000 * (secuenciaSimón.length + 1));
}

function manejarClickColor(colorSeleccionado) {
  if (!enJuego) return;

  secuenciaJugador.push(colorSeleccionado.color);

  const colorCorrecto = secuenciaSimón[secuenciaJugador.length - 1];

  if (colorSeleccionado.color === colorCorrecto.color) {
    if (secuenciaJugador.length === secuenciaSimón.length) {
      enJuego = false;
      generarSecuencia();
    }
  } else {
    secuenciaSimón = [];
    generarSecuencia();
    enJuego = false;
  }
}

boton.addEventListener("click", function () {
  const nombre = inputNombre.value;
  if (nombre) {
    generarSecuencia();
  }
});

document.getElementById("rojo").addEventListener("click", () => manejarClickColor({color: 'Rojo'}));
document.getElementById("azul").addEventListener("click", () => manejarClickColor({color: 'Azul'}));
document.getElementById("verde").addEventListener("click", () => manejarClickColor({color: 'Verde'}));
document.getElementById("amarillo").addEventListener("click", () => manejarClickColor({color: 'Amarillo'}));
