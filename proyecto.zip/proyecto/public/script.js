const formNombres = document.getElementById("formNombres");
const inputNombre = document.getElementById("inputNombre");
const boton = document.getElementById("boton");
const animacion = document.getElementById("animacion");
const listaEsferas = document.getElementById("listaEsferas");
let nombres = [];

let esferas = [
  { esfera: "Esfera 1", valor: "uno", boton: document.getElementById("esfera1") },
  { esfera: "Esfera 2", valor: "dos", boton: document.getElementById("esfera2") },
  { esfera: "Esfera 3", valor: "tres", boton: document.getElementById("esfera3") },
  { esfera: "Esfera 4", valor: "cuatro", boton: document.getElementById("esfera4") },
  { esfera: "Esfera 5", valor: "cinco", boton: document.getElementById("esfera5") },
  { esfera: "Esfera 6", valor: "seis", boton: document.getElementById("esfera6") },
  { esfera: "Esfera 7", valor: "siete", boton: document.getElementById("esfera7") }
];

let secuenciaDragonBall = [];
let secuenciaJugador = [];
let enJuego = false;

function mostrarEsferas() {
  listaEsferas.innerHTML = '';
  esferas.forEach(e => {
    const li = document.createElement("li");
    li.classList.add("list-group-item");
    li.textContent = `${e.esfera}`;
    listaEsferas.appendChild(li);
  });
}

function generarSecuencia() {
  const esferaAleatoria = esferas[Math.floor(Math.random() * esferas.length)];
  secuenciaDragonBall.push(esferaAleatoria);
  mostrarSecuencia();
}

function iluminarEsfera(esfera) {
  esfera.boton.classList.add("iluminar");
  setTimeout(() => {
    esfera.boton.classList.remove("iluminar");
  }, 500);
}

function mostrarSecuencia() {
  animacion.classList.add("ani");
  secuenciaDragonBall.forEach((esfera, index) => {
    setTimeout(() => {
      iluminarEsfera(esfera);
    }, 1000 * (index + 1));
  });

  setTimeout(() => {
    enJuego = true;
    secuenciaJugador = [];
  }, 1000 * (secuenciaDragonBall.length + 1));
}

function manejarClickEsfera(esferaSeleccionada) {
  if (!enJuego) return;

  secuenciaJugador.push(esferaSeleccionada.esfera);

  const esferaCorrecta = secuenciaDragonBall[secuenciaJugador.length - 1];

  if (esferaSeleccionada.esfera === esferaCorrecta.esfera) {
    if (secuenciaJugador.length === secuenciaDragonBall.length) {
      enJuego = false;
      generarSecuencia();
    }
  } else {
    secuenciaDragonBall = [];
    generarSecuencia();
    enJuego = false;
  }
}

boton.addEventListener("click", function () {
  const nombre = inputNombre.value;
  if (nombre) {
    const cancion = document.getElementById("cancion");
    cancion.play();

    setTimeout(() => {
      generarSecuencia();
    }, 5000);
  }
});

document.getElementById("esfera1").addEventListener("click", () => manejarClickEsfera({esfera: 'Esfera 1'}));
document.getElementById("esfera2").addEventListener("click", () => manejarClickEsfera({esfera: 'Esfera 2'}));
document.getElementById("esfera3").addEventListener("click", () => manejarClickEsfera({esfera: 'Esfera 3'}));
document.getElementById("esfera4").addEventListener("click", () => manejarClickEsfera({esfera: 'Esfera 4'}));
document.getElementById("esfera5").addEventListener("click", () => manejarClickEsfera({esfera: 'Esfera 5'}));
document.getElementById("esfera6").addEventListener("click", () => manejarClickEsfera({esfera: 'Esfera 6'}));
document.getElementById("esfera7").addEventListener("click", () => manejarClickEsfera({esfera: 'Esfera 7'}));
