// Dragon Ball Memory Game - Script con sistema de puntajes
// Selección de elementos del DOM
const formNombres = document.getElementById("formNombres");
const inputNombre = document.getElementById("inputNombre");
const boton = document.getElementById("boton");
const fondo = document.getElementById("body");
const esferascont = document.getElementById("esferascont");
const videoElement = document.getElementById("gif");
const botonreinicio = document.getElementById("reinicio");
const puntajesContainer = document.getElementById("puntajesContainer");

// Configuración del juego
let secuenciaDragonBall = [];
let secuenciaJugador = [];
let enJuego = false;
let nivelActual = 0;
const nivelMaximo = 7; // Para ganar el juego
let nombreJugador = ""; // Para guardar el nombre del jugador actual

// Definición de las esferas con sus propiedades
const esferas = [
  { id: "esfera1", valor: "uno", nombre: "Esfera 1" },
  { id: "esfera2", valor: "dos", nombre: "Esfera 2" },
  { id: "esfera3", valor: "tres", nombre: "Esfera 3" },
  { id: "esfera4", valor: "cuatro", nombre: "Esfera 4" },
  { id: "esfera5", valor: "cinco", nombre: "Esfera 5" },
  { id: "esfera6", valor: "seis", nombre: "Esfera 6" },
  { id: "esfera7", valor: "siete", nombre: "Esfera 7" }
];

// Para cada esfera, guardamos su elemento HTML
esferas.forEach(esfera => {
  esfera.elemento = document.getElementById(esfera.id);
});

// Array de clips para la función Perder - ACTUALIZADOS CON RUTAS ABSOLUTAS
const clips = [
  'https://i.redd.it/2vroytfyifxd1.gif',
  'https://pa1.aminoapps.com/6381/b46c149bf4cf8dd516a396b12c99e564dc67add1_hq.gif',
  'https://pa1.aminoapps.com/6056/c7d1c663d283d6ebadfbfd18506ca54c0727df71_hq.gif',
  'https://i.namu.wiki/i/_FAkeqK60OsNzT1KNCkdHLuIF34Xno7TW3kL9cKzIDlYNca_v7lc4_HbdV6epbSBTMbO80qXtYW3OrMUgUSNsg.gif',
];

// Variable para seguimiento de GIFs ya mostrados
let usados = []; 

/**
 * Gestiona el sistema de puntajes
 */
const puntajesManager = {
  // Obtiene los puntajes guardados o devuelve un array vacío
  obtenerPuntajes() {
    const puntajesGuardados = localStorage.getItem('dragonBallPuntajes');
    return puntajesGuardados ? JSON.parse(puntajesGuardados) : [];
  },
  
  // Guarda un nuevo puntaje
  guardarPuntaje(nombre, nivel) {
    const puntajes = this.obtenerPuntajes();
    puntajes.push({ nombre, nivel, fecha: new Date().toLocaleDateString() });
    
    // Ordenar por nivel (de mayor a menor)
    puntajes.sort((a, b) => b.nivel - a.nivel);
    
    // Mantener solo los 5 mejores
    const mejoresPuntajes = puntajes.slice(0, 5);
    
    // Guardar en localStorage
    localStorage.setItem('dragonBallPuntajes', JSON.stringify(mejoresPuntajes));
    
    return mejoresPuntajes;
  },
  
  // Muestra los puntajes en la tabla
  mostrarPuntajes() {
    const puntajes = this.obtenerPuntajes();
    const tablaPuntajes = document.getElementById("tablaPuntajes");
    
    if (!tablaPuntajes) {
      console.error("No se encontró la tabla de puntajes");
      return;
    }
    
    // Limpiar tabla actual
    const tbody = tablaPuntajes.querySelector("tbody");
    if (!tbody) {
      console.error("No se encontró el tbody de la tabla");
      return;
    }
    
    tbody.innerHTML = "";
    
    // Si no hay puntajes, mostrar mensaje
    if (puntajes.length === 0) {
      const fila = document.createElement("tr");
      const celda = document.createElement("td");
      celda.colSpan = 4;
      celda.textContent = "No hay puntajes registrados aún";
      celda.className = "text-center";
      fila.appendChild(celda);
      tbody.appendChild(fila);
      return;
    }
    
    // Llenar con nuevos datos
    puntajes.forEach((puntaje, index) => {
      const fila = document.createElement("tr");
      
      // Crear celdas
      const celdaPosicion = document.createElement("td");
      celdaPosicion.textContent = index + 1;
      
      const celdaNombre = document.createElement("td");
      celdaNombre.textContent = puntaje.nombre;
      
      const celdaNivel = document.createElement("td");
      celdaNivel.textContent = puntaje.nivel;
      
      const celdaFecha = document.createElement("td");
      celdaFecha.textContent = puntaje.fecha;
      
      // Añadir celdas a la fila
      fila.appendChild(celdaPosicion);
      fila.appendChild(celdaNombre);
      fila.appendChild(celdaNivel);
      fila.appendChild(celdaFecha);
      
      // Añadir fila a la tabla
      tbody.appendChild(fila);
    });
  },
  
  // Comprueba si el puntaje actual entra en el Top 5
  esTopPuntaje(nivel) {
    const puntajes = this.obtenerPuntajes();
    
    // Si hay menos de 5 puntajes, definitivamente entra
    if (puntajes.length < 5) return true;
    
    // Si hay 5 o más, comprobar si es mejor que el último
    return nivel > puntajes[puntajes.length - 1].nivel;
  }
};

/**
 * Inicia el juego cuando se hace clic en el botón "¡Jugá!"
 */
function iniciarJuego() {
  nombreJugador = inputNombre.value.trim();
  if (!nombreJugador) {
    alert("Por favor, ingresa tu nombre para comenzar");
    return;
  }
  
  // Ocultar tabla de puntajes si está visible
  const puntajesContainer = document.getElementById("puntajesContainer");
  if (puntajesContainer) {
    puntajesContainer.classList.add("d-none");
  }
  
  // Mostrar indicador de nivel
  const nivelIndicador = document.getElementById("nivelIndicador");
  if (nivelIndicador) {
    nivelIndicador.style.display = "block";
  }
  
  // Reproducir música de fondo
  const cancion = document.getElementById("cancion");
  cancion.play().catch(err => {
    console.warn("No se pudo reproducir el audio automáticamente:", err);
  });
  
  // Animar el formulario para que desaparezca
  formNombres.classList.add("ani");
  
  // Resetear el juego
  secuenciaDragonBall = [];
  secuenciaJugador = [];
  nivelActual = 0;
  
  // Comenzar la primera secuencia después de un breve retraso
  setTimeout(generarSecuencia, 1000);
}

/**
 * Genera una nueva secuencia añadiendo una esfera aleatoria
 */
function generarSecuencia() {
  // Seleccionar una esfera aleatoria
  const esferaAleatoria = esferas[Math.floor(Math.random() * esferas.length)];
  secuenciaDragonBall.push(esferaAleatoria);
  nivelActual++;
  
  // Actualizar indicador de nivel actual
  actualizarNivelUI();
  
  // Mostrar la secuencia al jugador
  mostrarSecuencia();
}

/**
 * Actualiza el indicador de nivel en la interfaz
 */
function actualizarNivelUI() {
  const nivelIndicador = document.getElementById("nivelActual");
  if (nivelIndicador) {
    nivelIndicador.textContent = nivelActual;
  }
}

/**
 * Muestra la secuencia actual al jugador iluminando las esferas
 */
function mostrarSecuencia() {
  enJuego = false; // Impedir que el jugador haga clic durante la secuencia
  
  // Mostrar cada esfera de la secuencia con un intervalo
  secuenciaDragonBall.forEach((esfera, index) => {
    setTimeout(() => {
      iluminarEsfera(esfera);
    }, 1000 * (index + 1));
  });
  
  // Permitir que el jugador comience después de mostrar la secuencia completa
  setTimeout(() => {
    enJuego = true;
    secuenciaJugador = [];
  }, 1000 * (secuenciaDragonBall.length + 1));
}

/**
 * Ilumina una esfera temporalmente
 */
function iluminarEsfera(esfera) {
  esfera.elemento.classList.add("iluminar");
  setTimeout(() => {
    esfera.elemento.classList.remove("iluminar");
  }, 500); // Duración de la iluminación
}

/**
 * Maneja el clic del jugador en una esfera
 */
function manejarClickEsfera(esfera) {
  // Si no estamos en juego, ignorar clics
  if (!enJuego) return;
  
  // Iluminar la esfera clicada y añadir a la secuencia del jugador
  iluminarEsfera(esfera);
  secuenciaJugador.push(esfera);
  
  // Obtener el índice actual en la secuencia
  const indiceActual = secuenciaJugador.length - 1;
  
  // Verificar si la elección es correcta
  if (secuenciaJugador[indiceActual].id !== secuenciaDragonBall[indiceActual].id) {
    // ¡El jugador se equivocó!
    enJuego = false;
    console.log("¡Error! Llamando a Perder()");
    
    // Guardar puntaje antes de mostrar pantalla de derrota
    puntajesManager.guardarPuntaje(nombreJugador, nivelActual);
    
    Perder();
    return;
  }
  
  // Si completó correctamente la secuencia actual
  if (secuenciaJugador.length === secuenciaDragonBall.length) {
    enJuego = false;
    
    // Si alcanzó el nivel máximo, ganó el juego
    if (nivelActual >= nivelMaximo) {
      // Guardar puntaje máximo
      puntajesManager.guardarPuntaje(nombreJugador, nivelActual);
      setTimeout(Ganar, 1000);
    } else {
      // Si no, continuar con el siguiente nivel
      setTimeout(generarSecuencia, 1500);
    }
  }
}

/**
 * Función que se ejecuta cuando el jugador gana
 */
function Ganar() {
  // Efectos visuales de victoria
  esferas.forEach(esfera => {
    esfera.elemento.classList.add("ganar");
  });
  fondo.classList.add("shenlong");
  esferascont.classList.add("esferasbajan");
  
  // Guardar puntaje final
  puntajesManager.guardarPuntaje(nombreJugador, nivelActual);
  
  // Mostrar mensaje de victoria
  const mensajeVictoria = document.createElement("div");
  mensajeVictoria.className = "mensaje-victoria";
  mensajeVictoria.innerHTML = `
    <h1>¡Felicidades ${nombreJugador}!</h1>
    <p>Has completado ${nivelActual} niveles y has invocado a Shenlong.</p>
    <button class="btn btn-success mt-3" onclick="resetearJuego(event)">Jugar de nuevo</button>
  `;
  document.body.appendChild(mensajeVictoria);
  
  // Aquí podrías añadir sonidos o animaciones adicionales
  console.log("¡Ganaste! ¡Has invocado a Shenlong!");
}

/**
 * Función que se ejecuta cuando el jugador pierde
 */
/**
 * Función que se ejecuta cuando el jugador pierde
 */
function Perder() {
  console.log("¡Has perdido! Mostrando GIF aleatorio...");
  
  // Reiniciar la lista de usados si ya mostramos todos
  if (usados.length >= clips.length) {
    usados = [];
    console.log("Reiniciando lista de clips usados");
  }
  
  // Filtrar clips disponibles (no usados)
  const disponibles = clips.filter(clip => !usados.includes(clip));
  
  // Seleccionar uno aleatorio
  const elegidoIndex = Math.floor(Math.random() * disponibles.length);
  const elegido = disponibles[elegidoIndex];
  usados.push(elegido);
  
  console.log(`Clip seleccionado: ${elegido}`);
  
  // Limpiamos cualquier elemento de fondo que pudiera causar problemas
  const oldImgFallback = document.getElementById("imgFallback");
  if (oldImgFallback) {
    oldImgFallback.remove();
  }
  
  // Creamos un nuevo elemento para mostrar el GIF
  const imgFallback = document.createElement("img");
  imgFallback.id = "imgFallback";
  imgFallback.src = elegido;
  imgFallback.style.position = "fixed";
  imgFallback.style.top = "0";
  imgFallback.style.left = "0";
  imgFallback.style.width = "100vw";
  imgFallback.style.height = "100vh";
  imgFallback.style.objectFit = "contain";
  imgFallback.style.backgroundColor = "rgba(0,0,0,0.8)";
  imgFallback.style.zIndex = "9999"; // Aseguramos que esté por encima de todo
  imgFallback.style.display = "block";
  document.body.appendChild(imgFallback);
  
  // Mostrar mensaje de derrota y puntaje obtenido
  botonreinicio.innerHTML = `
    <h1>¡Has fallado!</h1>
    <p>Nivel alcanzado: ${nivelActual}</p>
    <div class="deathcont">
      <a href="index.html" class="reinicio" onclick="resetearJuego(event)"><p>REINTENTAR</p></a>
      <a href="../index.html" class="reinicio" onclick="CambiaPag(event)"><p>VOLVER</p></a>
      <button class="reinicio" onclick="mostrarPuntajes(event)"><p>VER PUNTAJES</p></button>
    </div>
  `;
  
  // Asegurarnos que el formulario principal está visible cuando se muestran los puntajes desde aquí
  if (formNombres) {
    formNombres.classList.remove("ani");
    formNombres.style.display = "flex";
    formNombres.style.transform = "translateY(0)";
  }
  
  botonreinicio.style.display = "block";
  botonreinicio.style.zIndex = "10000";
  botonreinicio.style.position = "absolute";
}

/**
 * Muestra la tabla de puntajes
 */
/**
 * Muestra la tabla de puntajes
 */
function mostrarPuntajes(event) {
  if (event) event.preventDefault();
  
  // Ocultar formulario inicial si está visible
  if (formNombres) {
    // En lugar de simplemente ocultarlo, lo mantenemos visible
    formNombres.style.display = "flex"; // Mantenemos el formulario visible
    formNombres.classList.remove("ani"); // Quitamos la animación si tuviera
  }
  
  // Ocultar botones de reinicio si existen
  if (botonreinicio) {
    botonreinicio.style.display = "none";
  }
  
  // Eliminar imagen de fondo si existe
  const imgFallback = document.getElementById("imgFallback");
  if (imgFallback) {
    imgFallback.style.display = "none";
  }
  
  // Obtener el contenedor de puntajes
  const puntajesContainer = document.getElementById("puntajesContainer");
  if (!puntajesContainer) {
    console.error("No se encontró el contenedor de puntajes");
    return;
  }
  
  // Mostrar tabla de puntajes
  puntajesManager.mostrarPuntajes();
  puntajesContainer.classList.remove("d-none");
  
  // Verificar si ya existe un botón para volver
  const botonVolverExistente = puntajesContainer.querySelector(".btn-primary");
  
  // Añadir botón para volver al juego solo si no existe
  if (!botonVolverExistente) {
    const botonVolver = document.createElement("button");
    botonVolver.className = "btn btn-primary mt-3";
    botonVolver.textContent = "Volver al inicio";
    botonVolver.onclick = function() {
      // Ocultar la tabla de puntajes
      puntajesContainer.classList.add("d-none");
      
      // Mostrar el formulario correctamente
      if (formNombres) {
        formNombres.style.display = "flex";
        formNombres.classList.remove("ani");
        // Asegurarnos que está posicionado correctamente
        formNombres.style.transform = "translateY(0)";
      }
    };
    puntajesContainer.appendChild(botonVolver);
  }
}

/**
 * Reinicia el juego después de perder
 */
function resetearJuego(event) {
  if (event) event.preventDefault();
  const nube = document.getElementById('nube');
  nube.classList.add('show'); // Asegúrate de que esta clase es la misma que en CambiaPag
  
  // Espera al efecto y luego recarga la página
  setTimeout(() => {
    location.reload(); // Recarga en lugar de cambiar de dirección
  }, 1000); // Mismo tiempo que en CambiaPag
}

/**
 * Función para cambiar de página con efecto de nube
 */
function CambiaPag(event) {
  event.preventDefault();
  const nube = document.getElementById('nube');
  nube.classList.add('show');
  
  setTimeout(() => {
    window.location.href = "../index.html";
  }, 1000);
}

// Función para precarga de imágenes (mejora el rendimiento)
function precargarImagenes() {
  console.log("Precargando GIFs...");
  clips.forEach(url => {
    const img = new Image();
    img.src = url;
  });
}

// Event Listeners

// Precargar imágenes cuando se carga la página
window.addEventListener('load', () => {
  precargarImagenes();
  
  // Asegurarse de que los elementos esenciales existen
  if (!document.getElementById("btnPuntajes")) {
    console.warn("No se encontró el botón de puntajes, añadiéndolo dinámicamente");
    const formNombres = document.getElementById("formNombres");
    if (formNombres && formNombres.querySelector("form")) {
      const btnPuntajes = document.createElement("button");
      btnPuntajes.id = "btnPuntajes";
      btnPuntajes.type = "button";
      btnPuntajes.className = "btn btn-secondary ms-2";
      btnPuntajes.textContent = "Ver Puntajes";
      btnPuntajes.addEventListener("click", mostrarPuntajes);
      formNombres.querySelector("form").appendChild(btnPuntajes);
    }
  }
  
  // Asegurarse de que el contenedor de puntajes existe
  if (!document.getElementById("puntajesContainer")) {
    console.warn("No se encontró el contenedor de puntajes, añadiéndolo dinámicamente");
    const contenedor = document.querySelector(".container");
    if (contenedor) {
      const puntajesContainer = document.createElement("div");
      puntajesContainer.id = "puntajesContainer";
      puntajesContainer.className = "mt-4 card p-3 bg-light d-none";
      puntajesContainer.innerHTML = `
        <h3 class="text-center mb-3">Top 5 Puntajes</h3>
        <table id="tablaPuntajes" class="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>Nombre</th>
              <th>Nivel</th>
              <th>Fecha</th>
            </tr>
          </thead>
          <tbody>
            <!-- Aquí se generarán las filas dinámicamente -->
          </tbody>
        </table>
      `;
      contenedor.insertBefore(puntajesContainer, contenedor.firstChild.nextSibling);
    }
  }
  
  // Añadir event listener al botón de puntajes
  const btnPuntajes = document.getElementById("btnPuntajes");
  if (btnPuntajes) {
    btnPuntajes.addEventListener("click", mostrarPuntajes);
  } else {
    console.error("No se pudo encontrar el botón de puntajes");
  }
});

// Botón para iniciar el juego
boton.addEventListener("click", iniciarJuego);

// Listeners para cada esfera del dragón
esferas.forEach(esfera => {
  esfera.elemento.addEventListener("click", () => manejarClickEsfera(esfera));
});