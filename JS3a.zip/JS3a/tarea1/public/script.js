const inputCampo = document.getElementById("numeros");
const mensaje = document.getElementById("mensaje");
const lista = document.getElementById("lista");

  inputCampo.addEventListener("input", () => {
    const numeros = obtenerNumeros();
    // También actualiza la lista en tiempo real
    lista.innerHTML = numeros.map(n => `<li>${n}</li>`).join("");
  });

  function obtenerNumeros() {
    return inputCampo.value
      .trim()
      .split(/\s+/)
      .map(n => parseInt(n))
      .filter(n => !isNaN(n));
  }

  function enviarNumeros() {
    const numeros = obtenerNumeros();

    if (numeros.length < 10 || numeros.length > 20) {
      mensaje.textContent = "❌ Debes ingresar entre 10 y 20 números válidos.";
      return;
    }

    fetch('/guardar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ numeros })
    })
    .then(res => res.text())
    .then(msg => {
      mensaje.textContent = msg;
    });
  }