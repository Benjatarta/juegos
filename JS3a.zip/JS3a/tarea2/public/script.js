document.getElementById('formArchivo').addEventListener('submit', async (e) => {
  e.preventDefault();
  const archivo = document.getElementById('archivo').files[0];
  const formData = new FormData();
  formData.append('archivo', archivo);

  const res = await fetch('/api/subir', {
    method: 'POST',
    body: formData
  });

  const data = await res.json();
  const contenedor = document.getElementById('resultado');

  contenedor.innerHTML = `
    <h2>Resultado</h2>
    <p><strong>Válidos:</strong> ${data.totalValidos}</p>
    <p><strong>Inválidos:</strong> ${data.totalInvalidos}</p>
    <p><strong>Porcentaje válidos:</strong> ${data.porcentaje}%</p>
    <h3>Números válidos ordenados:</h3>
    <pre>${data.validos.join('\n')}</pre>
  `;
});
