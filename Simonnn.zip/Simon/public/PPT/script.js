// Script limpio - Base para nuevo juego
// Sistema de puntajes eliminado completamente

// Selección de elementos del DOM
const formNombres = document.getElementById("formNombres");
const inputNombre = document.getElementById("inputNombre");
const boton = document.getElementById("boton");

// Variable para el nombre del jugador
let nombreJugador = "";

// Variables para el control del video de YouTube
let youtubePlayer = null;
let videoTimer = null;
let youtubeAPILoaded = false;
let watchedTime = 0; // Tiempo realmente reproducido
let lastUpdateTime = 0; // Para rastrear el tiempo

/**
 * Controla el video de YouTube
 */
const videoController = {
  // Crear iframe de YouTube dinámicamente y simple
  createVideoIframe() {
    // Buscar si ya existe un iframe o contenedor
    let videoContainer = document.getElementById('youtube-video-container');
    
    if (!videoContainer) {
      // Crear contenedor para el video
      videoContainer = document.createElement('div');
      videoContainer.id = 'youtube-video-container';
      // Insertar después del formulario
      const formNombres = document.getElementById('formNombres');
      formNombres.parentNode.insertBefore(videoContainer, formNombres.nextSibling);
    }
    
    // Crear iframe de YouTube
    const iframe = document.createElement('iframe');
    iframe.width = '560';
    iframe.height = '315';
    iframe.src = 'https://www.youtube.com/embed/a0j9p1-UhfQ?autoplay=1&mute=0&controls=0&modestbranding=1&rel=0&start=0&end=14&enablejsapi=1';
    iframe.title = 'YouTube video';
    iframe.frameBorder = '0';
    iframe.allow = 'autoplay; encrypted-media';
    iframe.allowFullscreen = true;
    iframe.id = 'youtube-iframe';
    iframe.style.cssText = 'width: 100%; height: 100%;';
    
    // Crear botón de skip
    const skipButton = document.createElement('button');
    skipButton.id = 'skip-video-btn';
    skipButton.textContent = 'Saltar intro';
    skipButton.style.cssText = `
      position: absolute;
      bottom: 5vw;
      right: 5vw;
      width: 7vw;
      height: 3vw;
      background: #f7665c;
      color: white;
      border: none;
      padding: 0.2vw 0.5vw 0.2vw 0.5vw;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      z-index: 1000;
      transition: all 0.3s ease-in-out;
    `;
    
    // Hover effect para el botón
    skipButton.addEventListener('mouseenter', () => {
      skipButton.style.background = '#fdafa9';
    });
    skipButton.addEventListener('mouseleave', () => {
      skipButton.style.background = '#f7665c';
    });
    
    // Click handler para el botón skip
    skipButton.addEventListener('click', () => {
      this.skipVideo();
    });
    
    // Limpiar contenedor y agregar nuevo iframe y botón
    videoContainer.innerHTML = '';
    videoContainer.appendChild(iframe);
    videoContainer.appendChild(skipButton);
    
    return videoContainer;
  },
  
  // Función para saltar el video manualmente
  skipVideo() {
    console.log('Video saltado manualmente');
    this.hideVideo();
  },
  
  trackPlayTime() {
    if (videoTimer) {
      clearInterval(videoTimer);
    }
    
    // Reset de variables de tiempo
    watchedTime = 0;
    lastUpdateTime = Date.now();
    
    // Intervalo para rastrear el tiempo de reproducción
    videoTimer = setInterval(() => {
      const currentTime = Date.now();
      const iframe = document.getElementById('youtube-iframe');
      
      if (iframe) {
        // Asumimos que el video se está reproduciendo si el iframe existe y es visible
        // En una implementación más robusta, podrías usar la API de YouTube para verificar el estado
        watchedTime += (currentTime - lastUpdateTime);
        lastUpdateTime = currentTime;
        
        // Verificar si hemos reproducido 14 segundos (14000 ms)
        if (watchedTime >= 14000) {
          console.log('Video reproducido por 14 segundos, ocultando...');
          this.hideVideo();
        }
      }
    }, 100); // Verificar cada 100ms
  },
  
  // Mostrar y reproducir el video
  showAndPlayVideo() {
    const videoContainer = this.createVideoIframe();
    // Iniciar el seguimiento del tiempo de reproducción
    this.trackPlayTime();
    console.log('Video iniciado, se ocultará después de 14 segundos de reproducción real');
  },
  
  // Ocultar el video con animación
  hideVideo() {
    const videoContainer = document.getElementById('youtube-video-container');
    if (videoContainer) {
      // Primero detener el video eliminando el iframe
      const iframe = document.getElementById('youtube-iframe');
      if (iframe) {
        iframe.src = 'about:blank'; // Detener la reproducción
      }
      
      // Agregar clase para animación de desaparición
      videoContainer.classList.add('desaparece');
    
      console.log('Video ocultado');
    }
    
    // Limpiar el timer
    if (videoTimer) {
      clearInterval(videoTimer);
      videoTimer = null;
    }
    
    // Reset de variables de tiempo
    watchedTime = 0;
    lastUpdateTime = 0;
  }
};

/**
 * Función base para iniciar el juego
 */
function iniciarJuego() {
  nombreJugador = inputNombre.value.trim();
  if (!nombreJugador) {
    // Usar validación nativa del navegador en lugar de alert
    inputNombre.reportValidity();
    return;
  }
  
  // Reproducir música de fondo
  const cancion = document.getElementById("cancion");
  cancion.play().catch(err => {
    console.warn("No se pudo reproducir el audio automáticamente:", err);
  });
  
  // Animar el formulario para que desaparezca
  formNombres.classList.add("ani");
  
  // Mostrar el contenedor del juego
  const juegoContainer = document.getElementById("juegoContainer");
  if (juegoContainer) {
    juegoContainer.style.display = "block";
  }
  
  // Mostrar y reproducir el video de YouTube
  try {
    // Esperar un poco para que el formulario termine de animarse
    setTimeout(() => {
      videoController.showAndPlayVideo();
    }, 0);
  } catch (error) {
    console.error('Error al mostrar el video:', error);
  }
  
  // Aquí puedes agregar la lógica específica del nuevo juego
  console.log(`Iniciando juego para: ${nombreJugador}`);
}

// Resto de funciones del juego Piedra, Papel o Tijeras
const choices = {
    'piedra': '<div class="piedra opcion ani2"></div>',
    'papel': '<div class="papel opcion ani2"></div>',
    'tijeras': '<div class="tijeras opcion ani2"></div>'
};

const choiceNames = {
    'piedra': 'Piedra',
    'papel': 'Papel',
    'tijeras': 'Tijeras'
};

function getComputerChoice() {
    const options = ['piedra', 'papel', 'tijeras'];
    return options[Math.floor(Math.random() * options.length)];
}

function determineWinner(userChoice, computerChoice) {
    if (userChoice === computerChoice) {
        return 'tie';
    }
    
    if (
        (userChoice === 'piedra' && computerChoice === 'tijeras') ||
        (userChoice === 'papel' && computerChoice === 'piedra') ||
        (userChoice === 'tijeras' && computerChoice === 'papel')
    ) {
        return 'win';
    } else {
        return 'lose';
    }
}

function playGame(userChoice) {
    const computerChoice = getComputerChoice();
    const result = determineWinner(userChoice, computerChoice);
    
    const resultDiv = document.getElementById('result');
    
    let resultText = '';
    let resultClass = '';
    
    switch(result) {
        case 'win':
            resultText = '¡Ganaste!';
            resultClass = 'winner';
            break;
        case 'lose':
            resultText = '¡Perdiste!';
            resultClass = 'loser';
            break;
        case 'tie':
            resultText = '¡Empate!';
            resultClass = 'tie';
            break;
    }
    
    resultDiv.innerHTML = `
        <div class="choices ani3">
            <span class="emoji">${choices[userChoice]}</span>
            <span class="vs">VS</span>
            <span class="emoji">${choices[computerChoice]}</span>
        </div>
        <div style="margin: 10px 0; font-size: 1.2em;">
            Gokú: ${choiceNames[userChoice]} | Vegeta: ${choiceNames[computerChoice]}
        </div>
        <div class="game-result ${resultClass}">
            ${resultText}
        </div>
    `;
}

/**
 * Reinicia el juego después de perder/ganar
 */
function resetearJuego(event) {
  if (event) event.preventDefault();
  const nube = document.getElementById('nube');
  nube.classList.add('show');
  
  // Espera al efecto y luego recarga la página
  setTimeout(() => {
    location.reload();
  }, 1000);
}

/**
 * Función para cambiar de página con efecto de nube
 */
function CambiaPag(event) {
  event.preventDefault();
  const nube = document.getElementById('nube');
  nube.classList.add('show');
  
  setTimeout(() => {
    window.location.href = "../index.html";
  }, 1000);
}

// Event Listeners
window.addEventListener('load', () => {
  // Habilitar validación del formulario usando required
  inputNombre.setAttribute("required", "true");
  
  // Agregar listener para la tecla Enter en el formulario
  formNombres.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      iniciarJuego();
    }
  });
});

// Botón para iniciar el juego
boton.addEventListener("click", iniciarJuego);