// Selección de elementos del DOM
const formJugadores = document.getElementById("formJugadores");
const inputNombreJ1 = document.getElementById("inputNombreJ1");
const inputNombreJ2 = document.getElementById("inputNombreJ2");
const botonJ1 = document.getElementById("botonJ1");
const botonJ2 = document.getElementById("botonJ2");
const estadoJ1 = document.getElementById("estadoJ1");
const estadoJ2 = document.getElementById("estadoJ2");
const botonIniciarJuego = document.getElementById("botonIniciarJuego");
const juegoContainer = document.getElementById("juegoContainer");
const jugadoresInfo = document.getElementById("jugadoresInfo");

// Variables para los jugadores
let nombreJugador1 = "";
let nombreJugador2 = "";
let jugador1Listo = false;
let jugador2Listo = false;

// Variables del juego Ta-Te-Ti
let board = Array(9).fill(null);
let currentPlayer = 'X';
let gameActive = true;
const statusDisplay = document.getElementById('status');
const cells = document.querySelectorAll('.cell');
let winningPattern = null;

/**
 * Valida el nombre del jugador 1 y habilita su botón
 */
function validarJugador1() {
    const nombre = inputNombreJ1.value.trim();
    if (nombre.length > 0) {
        botonJ1.disabled = false;
        botonJ1.classList.remove("btn-secondary");
        botonJ1.classList.add("btn-primary");
    } else {
        botonJ1.disabled = true;
        botonJ1.classList.remove("btn-primary");
        botonJ1.classList.add("btn-secondary");
        jugador1Listo = false;
        estadoJ1.textContent = "Esperando...";
        estadoJ1.className = "badge bg-secondary";
        verificarAmbosJugadores();
    }
}

/**
 * Valida el nombre del jugador 2 y habilita su botón
 */
function validarJugador2() {
    const nombre = inputNombreJ2.value.trim();
    if (nombre.length > 0) {
        botonJ2.disabled = false;
        botonJ2.classList.remove("btn-secondary");
        botonJ2.classList.add("btn-primary");
    } else {
        botonJ2.disabled = true;
        botonJ2.classList.remove("btn-primary");
        botonJ2.classList.add("btn-secondary");
        jugador2Listo = false;
        estadoJ2.textContent = "Esperando...";
        estadoJ2.className = "badge bg-secondary";
        verificarAmbosJugadores();
    }
}

/**
 * Marca al jugador 1 como listo
 */
function marcarJugador1Listo() {
    nombreJugador1 = inputNombreJ1.value.trim();
    if (nombreJugador1) {
        jugador1Listo = true;
        botonJ1.textContent = "¡Listo!";
        botonJ1.disabled = true;
        botonJ1.classList.remove("btn-primary");
        botonJ1.classList.add("btn-success");
        estadoJ1.textContent = "¡Listo!";
        estadoJ1.className = "badge bg-success";
        inputNombreJ1.disabled = true;
        verificarAmbosJugadores();
    }
}

/**
 * Marca al jugador 2 como listo
 */
function marcarJugador2Listo() {
    nombreJugador2 = inputNombreJ2.value.trim();
    if (nombreJugador2) {
        jugador2Listo = true;
        botonJ2.textContent = "¡Listo!";
        botonJ2.disabled = true;
        botonJ2.classList.remove("btn-primary");
        botonJ2.classList.add("btn-success");
        estadoJ2.textContent = "¡Listo!";
        estadoJ2.className = "badge bg-success";
        inputNombreJ2.disabled = true;
        verificarAmbosJugadores();
    }
}

/**
 * Verifica si ambos jugadores están listos y muestra el botón de iniciar
 */
function verificarAmbosJugadores() {
    if (jugador1Listo && jugador2Listo) {
        botonIniciarJuego.style.display = "block";
        botonIniciarJuego.classList.add("btn-success");
        botonIniciarJuego.classList.remove("btn-secondary");
    } else {
        botonIniciarJuego.style.display = "none";
    }
}

/**
 * Inicia el juego cuando ambos jugadores están listos
 */
function iniciarJuego() {
    if (!jugador1Listo || !jugador2Listo) {
        console.warn("No se puede iniciar el juego: no todos los jugadores están listos");
        return;
    }
    
    // Animar el formulario para que desaparezca
    formJugadores.classList.add("ani");
    
    // Mostrar el contenedor del juego después de la animación
    setTimeout(() => {
        juegoContainer.style.display = "block";
        jugadoresInfo.textContent = `${nombreJugador1} (Goku) vs ${nombreJugador2} (Vegeta)`;
        const personaje = "Goku"; // El primer turno siempre es para Goku (jugador X)
        statusDisplay.textContent = `Turno de ${nombreJugador1} (${personaje})`;
        initializeGame();
    }, 500);
    
    console.log(`Iniciando juego: ${nombreJugador1} vs ${nombreJugador2}`);
}

/**
 * Inicializa el juego Ta-Te-Ti
 */
function initializeGame() {
    board = Array(9).fill(null);
    currentPlayer = 'X';
    gameActive = true;
    winningPattern = null;
    
    // Mostrar "Goku" para jugador X (jugador1) y "Vegeta" para jugador O (jugador2)
    const personaje = currentPlayer === 'X' ? "Goku" : "Vegeta";
    statusDisplay.textContent = `Turno de ${nombreJugador1} (${personaje})`;
    
    cells.forEach((cell, index) => {
        // Limpiar cualquier contenido anterior
        cell.innerHTML = '';
        cell.className = 'cell';
        cell.disabled = false;
        cell.onclick = () => handleCellClick(index);
    });
}

/**
 * Crea un div para X u O
 */
function createMarkerDiv(player) {
    const markerDiv = document.createElement('div');
    markerDiv.className = `marker marker-${player}`;
    
    // Añadir manejo de errores para las imágenes
    if (player === 'X') {
        // Crear una imagen para verificar si carga correctamente
        const testImg = new Image();
        testImg.onload = function() {
            console.log("Imagen X cargada correctamente");
        };
        testImg.onerror = function() {
            console.warn("Error al cargar la imagen X");
            markerDiv.classList.add('error');
        };
        testImg.src = '../extras/vegeta.png';
    } else {
        // Crear una imagen para verificar si carga correctamente
        const testImg = new Image();
        testImg.onload = function() {
            console.log("Imagen O cargada correctamente");
        };
        testImg.onerror = function() {
            console.warn("Error al cargar la imagen O");
            markerDiv.classList.add('error');
        };
        testImg.src = '../extras/goku.png';
    }
    
    return markerDiv;
}

/**
 * Maneja el clic en una celda del tablero
 */
function handleCellClick(index) {
    if (!gameActive || board[index] !== null) {
        return;
    }

    board[index] = currentPlayer;
    
    // Crear y añadir el div para X u O
    const markerDiv = createMarkerDiv(currentPlayer);
    cells[index].appendChild(markerDiv);
    cells[index].classList.add(currentPlayer);
    cells[index].disabled = true;

    if (checkWinner()) {
        const winnerName = currentPlayer === 'X' ? nombreJugador1 : nombreJugador2;
        const personaje = currentPlayer === 'X' ? "Goku" : "Vegeta";
        statusDisplay.textContent = `¡${winnerName} (${personaje}) GANA!`;
        gameActive = false;
        highlightWinningCells();
    } else if (board.every(cell => cell !== null)) {
        statusDisplay.textContent = "¡EMPATE!";
        gameActive = false;
    } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        const nextPlayerName = currentPlayer === 'X' ? nombreJugador1 : nombreJugador2;
        const personaje = currentPlayer === 'X' ? "Goku" : "Vegeta";
        statusDisplay.textContent = `Turno de ${nextPlayerName} (${personaje})`;
    }
}

/**
 * Verifica si hay un ganador
 */
function checkWinner() {
    const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // filas
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // columnas
        [0, 4, 8], [2, 4, 6]             // diagonales
    ];

    for (let pattern of winPatterns) {
        const [a, b, c] = pattern;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            winningPattern = pattern;
            return true;
        }
    }
    return false;
}

/**
 * Resalta las celdas ganadoras
 */
function highlightWinningCells() {
    if (winningPattern) {
        winningPattern.forEach(index => {
            cells[index].classList.add('winner');
        });
    }
}

/**
 * Reinicia el juego sin recargar la página
 */
function resetearJuego(event) {
    if (event) event.preventDefault();
    
    // Reiniciar el tablero y el estado del juego inmediatamente
    // sin mostrar la nube ni usar setTimeout
    initializeGame();
}

/**
 * Función para cambiar de página con efecto de nube
 */
function CambiaPag(event) {
    event.preventDefault();
    const nube = document.getElementById('nube');
    nube.classList.add('show');
    
    setTimeout(() => {
        window.location.href = "../index.html";
    }, 1000);
}

// Event Listeners
window.addEventListener('load', () => {
    // Inicializar el contenedor de juego como oculto
    juegoContainer.style.display = "none";
    
    // Validación en tiempo real para el jugador 1
    inputNombreJ1.addEventListener("input", validarJugador1);
    
    // Validación en tiempo real para el jugador 2
    inputNombreJ2.addEventListener("input", validarJugador2);
    
    // Listener para Enter en el campo del jugador 1
    inputNombreJ1.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            event.preventDefault();
            if (!botonJ1.disabled) {
                marcarJugador1Listo();
            }
        }
    });
    
    // Listener para Enter en el campo del jugador 2
    inputNombreJ2.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            event.preventDefault();
            if (!botonJ2.disabled) {
                marcarJugador2Listo();
            }
        }
    });
    
    // Listener para Enter en el botón de iniciar juego
    document.addEventListener("keypress", function(event) {
        if (event.key === "Enter" && jugador1Listo && jugador2Listo) {
            event.preventDefault();
            iniciarJuego();
        }
    });
});

// Event listeners para los botones
botonJ1.addEventListener("click", marcarJugador1Listo);
botonJ2.addEventListener("click", marcarJugador2Listo);
botonIniciarJuego.addEventListener("click", iniciarJuego);