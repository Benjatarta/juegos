// Dragon Ball Memory Game - Script con sistema de puntajes
// Selección de elementos del DOM
const formNombres = document.getElementById("formNombres");
const inputNombre = document.getElementById("inputNombre");
const boton = document.getElementById("boton");
const fondo = document.getElementById("body");
const esferascont = document.getElementById("esferascont");
const videoElement = document.getElementById("gif");
const botonreinicio = document.getElementById("reinicio");
const puntajesContainer = document.getElementById("puntajesContainer");
const btnPuntajes = document.getElementById("btnPuntajes");
const volverInicio = document.getElementById("volverInicio");
const adminModeBtn = document.getElementById("adminModeBtn");
const adminContainer = document.getElementById("adminContainer");
const inputPuntaje = document.getElementById("inputPuntaje");
const btnEstablecerPuntaje = document.getElementById("btnEstablecerPuntaje");

// Configuración del juego
let secuenciaDragonBall = [];
let secuenciaJugador = [];
let enJuego = false;
let mostrandoSecuencia = false; // Nueva variable para rastrear cuando se muestra secuencia
let nivelActual = 0;
const nivelMaximo = 20000; // Para ganar el juego
let nombreJugador = ""; // Para guardar el nombre del jugador actual
let modoAdmin = false; // Nuevo: indica si estamos en modo administrador

// Definición de las esferas con sus propiedades
const esferas = [
  { id: "esfera1", valor: "uno", nombre: "Esfera 1" },
  { id: "esfera2", valor: "dos", nombre: "Esfera 2" },
  { id: "esfera3", valor: "tres", nombre: "Esfera 3" },
  { id: "esfera4", valor: "cuatro", nombre: "Esfera 4" },
  { id: "esfera5", valor: "cinco", nombre: "Esfera 5" },
  { id: "esfera6", valor: "seis", nombre: "Esfera 6" },
  { id: "esfera7", valor: "siete", nombre: "Esfera 7" }
];

// Para cada esfera, guardamos su elemento HTML
esferas.forEach(esfera => {
  esfera.elemento = document.getElementById(esfera.id);
});

// Array de clips para la función Perder - ACTUALIZADOS CON RUTAS ABSOLUTAS
const clips = [
  'https://i.redd.it/2vroytfyifxd1.gif',
  'https://pa1.aminoapps.com/6381/b46c149bf4cf8dd516a396b12c99e564dc67add1_hq.gif',
  'https://pa1.aminoapps.com/6056/c7d1c663d283d6ebadfbfd18506ca54c0727df71_hq.gif',
  'https://i.namu.wiki/i/_FAkeqK60OsNzT1KNCkdHLuIF34Xno7TW3kL9cKzIDlYNca_v7lc4_HbdV6epbSBTMbO80qXtYW3OrMUgUSNsg.gif',
];

// Variable para seguimiento de GIFs ya mostrados
let usados = []; 

/**
 * Gestiona el sistema de puntajes
 */
const puntajesManager = {
  // Obtiene los puntajes guardados o devuelve un array vacío
  obtenerPuntajes() {
    const puntajesGuardados = localStorage.getItem('dragonBallPuntajes');
    return puntajesGuardados ? JSON.parse(puntajesGuardados) : [];
  },
  
  // Guarda un nuevo puntaje y retorna información sobre el logro
  guardarPuntaje(nombre, nivel) {
    const puntajes = this.obtenerPuntajes();
    const esPrimerPuntaje = puntajes.length === 0;
    const esNuevoTop1 = !esPrimerPuntaje && nivel > puntajes[0].nivel;
    const esNuevoPuntajeTop5 = this.esTopPuntaje(nivel);
    
    puntajes.push({ nombre, nivel, fecha: new Date().toLocaleDateString() });
    
    // Ordenar por nivel (de mayor a menor)
    puntajes.sort((a, b) => b.nivel - a.nivel);
    
    // Mantener solo los 5 mejores
    const mejoresPuntajes = puntajes.slice(0, 5);
    
    // Guardar en localStorage
    localStorage.setItem('dragonBallPuntajes', JSON.stringify(mejoresPuntajes));
    
    // Retornar información sobre el logro alcanzado
    return {
      esPrimerPuntaje,
      esNuevoTop1,
      esNuevoPuntajeTop5,
      posicion: mejoresPuntajes.findIndex(p => p.nombre === nombre && p.nivel === nivel && p.fecha === new Date().toLocaleDateString()) + 1
    };
  },
  
  // Muestra los puntajes en la tabla
  mostrarPuntajes(esDerrota = false) {
    const puntajes = this.obtenerPuntajes();
    const tablaPuntajes = document.getElementById("tablaPuntajes");
    
    if (!tablaPuntajes) {
      console.error("No se encontró la tabla de puntajes");
      return;
    }
    
    // Limpiar tabla actual
    const tbody = tablaPuntajes.querySelector("tbody");
    if (!tbody) {
      console.error("No se encontró el tbody de la tabla");
      return;
    }
    
    tbody.innerHTML = "";
    
    // Si no hay puntajes, mostrar mensaje
    if (puntajes.length === 0) {
      const fila = document.createElement("tr");
      const celda = document.createElement("td");
      celda.colSpan = 4;
      celda.textContent = "No hay puntajes registrados aún";
      celda.className = "text-center";
      fila.appendChild(celda);
      tbody.appendChild(fila);
      return;
    }
    
    // Llenar con nuevos datos
    puntajes.forEach((puntaje, index) => {
      const fila = document.createElement("tr");
      
      // Crear celdas
      const celdaPosicion = document.createElement("td");
      celdaPosicion.textContent = index + 1;
      
      const celdaNombre = document.createElement("td");
      celdaNombre.textContent = puntaje.nombre;
      
      const celdaNivel = document.createElement("td");
      celdaNivel.textContent = puntaje.nivel;
      
      const celdaFecha = document.createElement("td");
      celdaFecha.textContent = puntaje.fecha;
      
      // Añadir celdas a la fila
      fila.appendChild(celdaPosicion);
      fila.appendChild(celdaNombre);
      fila.appendChild(celdaNivel);
      fila.appendChild(celdaFecha);
      
      // Añadir fila a la tabla
      tbody.appendChild(fila);
    });
    
    // Mostrar la tabla con la clase correspondiente según el contexto
    if (esDerrota) {
      puntajesContainer.classList.add("muestrapuntajepierde");
    }
  },
  
  // Oculta la tabla de puntajes
  ocultarPuntajes() {
    puntajesContainer.classList.remove("muestrapuntaje", "muestrapuntajepierde");
  },
  
  // Comprueba si el puntaje actual entra en el Top 5
  esTopPuntaje(nivel) {
    const puntajes = this.obtenerPuntajes();
    
    // Si hay menos de 5 puntajes, definitivamente entra
    if (puntajes.length < 5) return true;
    
    // Si hay 5 o más, comprobar si es mejor que el último
    return nivel > puntajes[puntajes.length - 1].nivel;
  },
  
  // Comprobar si es nuevo récord (Top 1)
  esTop1(nivel) {
    const puntajes = this.obtenerPuntajes();
    
    // Si no hay puntajes, definitivamente es top 1
    if (puntajes.length === 0) return true;
    
    // Comprobar si supera el mejor puntaje actual
    return nivel > puntajes[0].nivel;
  }
};

/**
 * Inicia el juego cuando se hace clic en el botón "¡Jugá!"
 */
function iniciarJuego() {
  nombreJugador = inputNombre.value.trim();
  if (!nombreJugador) {
    // Usar validación nativa del navegador en lugar de alert
    inputNombre.reportValidity();
    return;
  }
  
  // Ocultar tabla de puntajes si está visible
  puntajesManager.ocultarPuntajes();
  
  // Mostrar indicador de nivel
  const nivelIndicador = document.getElementById("nivelIndicador");
  if (nivelIndicador) {
    nivelIndicador.style.display = "block";
  }
  
  // Reproducir música de fondo
  const cancion = document.getElementById("cancion");
  cancion.play().catch(err => {
    console.warn("No se pudo reproducir el audio automáticamente:", err);
  });
  
  // Animar el formulario para que desaparezca
  formNombres.classList.add("ani");
  
  // Resetear el juego
  secuenciaDragonBall = [];
  secuenciaJugador = [];
  nivelActual = 0;
  
  // Comenzar la primera secuencia después de un breve retraso
  setTimeout(generarSecuencia, 1000);
}

/**
 * NUEVO: Inicia el juego en modo administrador con un puntaje específico
 */
function iniciarJuegoAdmin() {
  // Verificar que se haya ingresado un nombre y un puntaje válido
  nombreJugador = inputNombre.value.trim();
  const puntajeObjetivo = parseInt(inputPuntaje.value.trim());
  
  if (!nombreJugador) {
    inputNombre.reportValidity();
    return;
  }
  
  if (isNaN(puntajeObjetivo) || puntajeObjetivo <= 0) {
    alert("Por favor, ingresa un puntaje válido mayor que 0");
    return;
  }
  
  // Ocultar tabla de puntajes si está visible
  puntajesManager.ocultarPuntajes();
  
  // Mostrar indicador de nivel
  const nivelIndicador = document.getElementById("nivelIndicador");
  if (nivelIndicador) {
    nivelIndicador.style.display = "block";
  }
  
  // Reproducir música de fondo
  const cancion = document.getElementById("cancion");
  cancion.play().catch(err => {
    console.warn("No se pudo reproducir el audio automáticamente:", err);
  });
  
  // Animar el formulario para que desaparezca
  formNombres.classList.add("ani");
  adminContainer.classList.add("ani");
  
  // Resetear el juego
  secuenciaDragonBall = [];
  secuenciaJugador = [];
  nivelActual = 0;
  modoAdmin = true;
  
  // Generar secuencia de longitud específica
  for (let i = 0; i < puntajeObjetivo; i++) {
    const esferaAleatoria = esferas[Math.floor(Math.random() * esferas.length)];
    secuenciaDragonBall.push(esferaAleatoria);
  }
  
  nivelActual = puntajeObjetivo;
  actualizarNivelUI();
  
  // Mostrar la secuencia completa al jugador después de un breve retraso
  setTimeout(mostrarSecuencia, 1000);
}

/**
 * Genera una nueva secuencia añadiendo una esfera aleatoria
 */
function generarSecuencia() {
  // Seleccionar una esfera aleatoria
  const esferaAleatoria = esferas[Math.floor(Math.random() * esferas.length)];
  secuenciaDragonBall.push(esferaAleatoria);
  nivelActual++;
  
  // Actualizar indicador de nivel actual
  actualizarNivelUI();
  
  // Mostrar la secuencia al jugador
  mostrarSecuencia();
}

/**
 * Actualiza el indicador de nivel en la interfaz
 */
function actualizarNivelUI() {
  const nivelIndicador = document.getElementById("nivelActual");
  if (nivelIndicador) {
    nivelIndicador.textContent = nivelActual;
  }
}

/**
 * Muestra la secuencia actual al jugador iluminando las esferas
 */
function mostrarSecuencia() {
  enJuego = false; // Impedir que el jugador haga clic durante la secuencia
  mostrandoSecuencia = true; // Indicar que estamos mostrando la secuencia
  
  // Agregar clase para desactivar hover durante la secuencia
  esferascont.classList.add("desactivar-hover");
  
  // Mostrar cada esfera de la secuencia con un intervalo (más rápido - 800ms en lugar de 1000ms)
  secuenciaDragonBall.forEach((esfera, index) => {
    setTimeout(() => {
      iluminarEsfera(esfera);
    }, 800 * (index + 1)); // Aumentado velocidad: 800ms en lugar de 1000ms
  });
  
  // Permitir que el jugador comience después de mostrar la secuencia completa
  setTimeout(() => {
    enJuego = true;
    mostrandoSecuencia = false;
    esferascont.classList.remove("desactivar-hover");
    secuenciaJugador = [];
  }, 800 * (secuenciaDragonBall.length + 1));
}

/**
 * Ilumina una esfera temporalmente
 */
function iluminarEsfera(esfera) {
  esfera.elemento.classList.add("iluminar");
  setTimeout(() => {
    esfera.elemento.classList.remove("iluminar");
  }, 400); // Duración de la iluminación (más rápido - 400ms en lugar de 500ms)
}

/**
 * Maneja el clic del jugador en una esfera
 */
function manejarClickEsfera(esfera) {
  // Si no estamos en juego o estamos mostrando secuencia, ignorar clics
  if (!enJuego || mostrandoSecuencia) return;
  
  // Iluminar la esfera clicada y añadir a la secuencia del jugador
  iluminarEsfera(esfera);
  secuenciaJugador.push(esfera);
  
  // Obtener el índice actual en la secuencia
  const indiceActual = secuenciaJugador.length - 1;
  
  // Verificar si la elección es correcta
  if (secuenciaJugador[indiceActual].id !== secuenciaDragonBall[indiceActual].id) {
    // ¡El jugador se equivocó!
    enJuego = false;
    console.log("¡Error! Verificando si es nuevo Top 1...");
    
    // Verificar si logró nuevo Top 1 antes de guardar
    const esNuevoTop1 = puntajesManager.esTop1(nivelActual);
    
    // Guardar el puntaje
    puntajesManager.guardarPuntaje(nombreJugador, nivelActual);
    
    // Si es nuevo Top 1, activar función Ganar
    if (esNuevoTop1) {
      console.log("¡Nuevo récord logrado! Activando función Ganar()");
      setTimeout(Ganar, 1000);
    } else {
      // Si no es Top 1, mostrar pantalla de derrota normal
      console.log("No es Top 1, mostrando pantalla de derrota");
      Perder();
    }
    return;
  }
  
  // Si completó correctamente la secuencia actual
  if (secuenciaJugador.length === secuenciaDragonBall.length) {
    enJuego = false;
    
    // Si alcanzó el nivel máximo (solo en modo normal) o completó el nivel en modo admin, ganó el juego
    if ((nivelActual >= nivelMaximo && !modoAdmin) || modoAdmin) {
      // Guardar puntaje
      puntajesManager.guardarPuntaje(nombreJugador, nivelActual);
      
      // En modo admin no se ejecuta Ganar automáticamente
      if (modoAdmin) {
        // Mostrar un mensaje personalizado para modo admin
        const mensajeVictoria = document.createElement("div");
        mensajeVictoria.className = "mensaje-victoria";
        mensajeVictoria.innerHTML = `
          <h1>¡Prueba completada, ${nombreJugador}!</h1>
          <p>Has completado los ${nivelActual} niveles en modo administrador.</p>
          <button class="boton btninicio" onclick="resetearJuego(event)">Jugar de nuevo</button>
        `;
        document.body.appendChild(mensajeVictoria);
      } else {
        setTimeout(Ganar, 1000);
      }
    } else {
      // Si no, continuar con el siguiente nivel (solo en modo normal)
      setTimeout(generarSecuencia, 1500);
    }
  }
}

/**
 * Función que se ejecuta cuando el jugador gana (completando el juego o consiguiendo nuevo Top 1)
 */
function Ganar() {
  // Efectos visuales de victoria
  esferas.forEach(esfera => {
    esfera.elemento.classList.add("ganar");
  });
  fondo.classList.add("shenlong");
  esferascont.classList.add("esferasbajan");
  const nivelIndicador = document.getElementById("nivelIndicador");
  if (nivelIndicador) {
    nivelIndicador.style.display = "none";
  }
  
  // Obtener los puntajes para verificar si es el mejor puntaje
  const puntajes = puntajesManager.obtenerPuntajes();
  let mensajeRecord = "";
  
  // Verificar si es el mejor puntaje (Top 1)
  if (puntajes.length > 0 && puntajes[0].nombre === nombreJugador && puntajes[0].nivel === nivelActual) {
    mensajeRecord = `<p>¡Tienes el récord! Haz conseguido ${nivelActual} puntos!</p>`;
  } else {
    mensajeRecord = `<p>¡Completaste el juego con ${nivelActual} puntos!</p>`;
  }
  
  // Mostrar mensaje de victoria
  const mensajeVictoria = document.createElement("div");
  mensajeVictoria.className = "mensaje-victoria";
  mensajeVictoria.innerHTML = `
    <h1>¡Felicidades ${nombreJugador}!</h1>
    ${mensajeRecord}
    <button class="boton btninicio" onclick="resetearJuego(event)">Jugar de nuevo</button>
  `;
  document.body.appendChild(mensajeVictoria);
  
  console.log("¡Ganaste! ¡Has invocado a Shenlong!");
}

/**
 * Función que se ejecuta cuando el jugador pierde y NO logra un nuevo Top 1
 */
function Perder() {
  console.log("¡Has perdido! Mostrando pantalla de derrota");
  
  // Reiniciar la lista de usados si ya mostramos todos
  if (usados.length >= clips.length) {
    usados = [];
    console.log("Reiniciando lista de clips usados");
  }
  
  // Filtrar clips disponibles (no usados)
  const disponibles = clips.filter(clip => !usados.includes(clip));
  
  // Seleccionar uno aleatorio
  const elegidoIndex = Math.floor(Math.random() * disponibles.length);
  const elegido = disponibles[elegidoIndex];
  usados.push(elegido);
  
  console.log(`Clip seleccionado: ${elegido}`);
  
  // Limpiamos cualquier elemento de fondo que pudiera causar problemas
  const oldImgFallback = document.getElementById("imgFallback");
  if (oldImgFallback) {
    oldImgFallback.remove();
  }
  
  // Creamos un nuevo elemento para mostrar el GIF
  const imgFallback = document.createElement("img");
  imgFallback.id = "imgFallback";
  imgFallback.src = elegido;
  imgFallback.style.position = "fixed";
  imgFallback.style.top = "0";
  imgFallback.style.left = "0";
  imgFallback.style.width = "100vw";
  imgFallback.style.height = "100vh";
  imgFallback.style.objectFit = "contain";
  imgFallback.style.backgroundColor = "rgba(0,0,0,0.8)";
  imgFallback.style.zIndex = "30"; // Aseguramos que esté por encima de todo
  imgFallback.style.display = "block";
  document.body.appendChild(imgFallback);
  
  // Mostrar mensaje de derrota y puntaje obtenido
  botonreinicio.innerHTML = `
    <h1>¡Has fallado!</h1>
    <p class="nivelDeath">Puntos alcanzados: ${nivelActual}</p>
    <div class="deathcont">
      <a href="index.html" class="reinicio" onclick="resetearJuego(event)"><p>REINTENTAR</p></a>
      <a href="../index.html" class="volverbtn" onclick="CambiaPag(event)"><p>VOLVER</p></a>
    </div>
  `;
  
  botonreinicio.style.display = "flex";
  botonreinicio.style.zIndex = "31";
  botonreinicio.style.position = "absolute";
  puntajesContainer.classList.add("muestrapierde");
  // Siempre mostrar la tabla de puntajes cuando pierde
  puntajesManager.mostrarPuntajes(true); // true indica que es contexto de derrota
}

/**
 * NUEVO: Muestra u oculta el panel de administración
 */
function toggleAdminMode() {
  // Si no existe el contenedor, ignorar
  if (!adminContainer) return;
  
  // Alternar visibilidad del contenedor admin
  if (adminContainer.classList.contains("admin-visible")) {
    adminContainer.classList.remove("admin-visible");
  } else {
    adminContainer.classList.add("admin-visible");
  }
}

/**
 * Muestra la tabla de puntajes
 */
function mostrarPuntajes(event) {
  if (event) event.preventDefault();
  puntajesContainer.classList.add("muestrapuntaje");
  // Mostrar tabla de puntajes sin el estilo de derrota
  puntajesManager.mostrarPuntajes(false);
}

/**
 * Oculta la tabla de puntajes
 */
function ocultarPuntajes(event) {
  if (event) event.preventDefault();
  puntajesManager.ocultarPuntajes();
}

/**
 * Reinicia el juego después de perder
 */
function resetearJuego(event) {
  if (event) event.preventDefault();
  const nube = document.getElementById('nube');
  nube.classList.add('show'); // Asegúrate de que esta clase es la misma que en CambiaPag
  
  // Espera al efecto y luego recarga la página
  setTimeout(() => {
    location.reload(); // Recarga en lugar de cambiar de dirección
  }, 1000); // Mismo tiempo que en CambiaPag
}

/**
 * Función para cambiar de página con efecto de nube
 */
function CambiaPag(event) {
  event.preventDefault();
  const nube = document.getElementById('nube');
  nube.classList.add('show');
  
  setTimeout(() => {
    window.location.href = "../index.html";
  }, 1000);
}

// Función para precarga de imágenes (mejora el rendimiento)
function precargarImagenes() {
  console.log("Precargando GIFs...");
  clips.forEach(url => {
    const img = new Image();
    img.src = url;
  });
}

// Event Listeners
window.addEventListener('load', () => {
  precargarImagenes();
  
  // Cargar y mostrar los puntajes al inicio (ocultos con CSS)
  puntajesManager.mostrarPuntajes();
  
  // Habilitar validación del formulario usando required
  inputNombre.setAttribute("required", "true");
  
  // Agregar listener para la tecla Enter en el formulario
  formNombres.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      iniciarJuego();
    }
  });
  
  // Si existe el contenedor de administrador, agregar listener para Enter
  if (adminContainer) {
    adminContainer.addEventListener("keypress", function(event) {
      if (event.key === "Enter") {
        event.preventDefault();
        iniciarJuegoAdmin();
      }
    });
  }
  
  // Código secreto para acceder al modo admin
  let secretCode = [];
  const adminCode = "dragonadmin";
  
  document.addEventListener("keydown", function(event) {
    // Agregar la tecla presionada al array
    secretCode.push(event.key.toLowerCase());
    
    // Mantener solo las últimas N teclas (donde N es la longitud del código)
    if (secretCode.length > adminCode.length) {
      secretCode.shift();
    }
    
    // Verificar si el código coincide
    if (secretCode.join("") === adminCode) {
      toggleAdminMode();
      secretCode = []; // Reiniciar para evitar toggles múltiples
    }
  });
});

// Botón para iniciar el juego
boton.addEventListener("click", iniciarJuego);

// Botón para mostrar puntajes
btnPuntajes.addEventListener("click", mostrarPuntajes);

// Botón para volver al inicio desde los puntajes
volverInicio.addEventListener("click", ocultarPuntajes);

// Botón para modo admin (si existe)
if (btnEstablecerPuntaje) {
  btnEstablecerPuntaje.addEventListener("click", iniciarJuegoAdmin);
}

// Listeners para cada esfera del dragón
esferas.forEach(esfera => {
  esfera.elemento.addEventListener("click", () => manejarClickEsfera(esfera));
});

document.head.appendChild(style);